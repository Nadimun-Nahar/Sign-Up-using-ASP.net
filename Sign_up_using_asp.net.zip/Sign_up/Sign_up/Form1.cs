﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sign_up
{
    public partial class FrmRegister : Form
    {
        SqlConnection _connection;
        public FrmRegister()
        {
            InitializeComponent();

            String ConString = "Data Source=.;Initial Catalog=ReboxingDb;User ID=sa; Password=admin1@3;TrustServerCertificate=True";
            _connection = new SqlConnection(ConString);
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dataadapter = new SqlDataAdapter();
        }
       

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void UserName_TextChanged(object sender, EventArgs e)
        {

        }

        private void Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ConfirmPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPassword.Checked)
            {
                Password.PasswordChar = '\0';
                ConfirmPass.PasswordChar = '\0';

            }
            else
            {
                Password.PasswordChar = '*';
                ConfirmPass.PasswordChar = '*';
            }
        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            if (UserName.Text == "" && Password.Text == "" && ConfirmPass.Text == "")
            {
                MessageBox.Show("UserName and Password fields are emty", "Registration Faild", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else if (Password.Text == ConfirmPass.Text)
            {

                _connection.Open();
                string register = "Insert into Usertbl (UserName, Password) values ('" + UserName.Text + "', '" + Password.Text + "')";
                SqlCommand cmd = new SqlCommand(register, _connection);
                cmd.ExecuteNonQuery();
                _connection.Close();

                UserName.Text = "";
                Password.Text = "";
                ConfirmPass.Text = "";

                MessageBox.Show("Your Account has been Successfully created", "Registration Success", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }

            else
            {
                MessageBox.Show("Password does not Match, Please Re enter", "Registration Faild", MessageBoxButtons.OK, MessageBoxIcon.Error);

                Password.Text = "";
                ConfirmPass.Text = "";
                Password.Focus();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserName.Text = "";
            Password.Text = "";
            ConfirmPass.Text = "";                  
            UserName.Focus();

        }

        private void label6_Click(object sender, EventArgs e)
        {
            new frmLogIn().Show();
            this.Hide();


        }
    }
}
