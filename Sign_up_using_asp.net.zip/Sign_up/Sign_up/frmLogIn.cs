﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sign_up
{
    public partial class frmLogIn : Form
    {
        SqlConnection _connection;
        public frmLogIn()
        {
            InitializeComponent();
            String ConString = "Data Source=.;Initial Catalog=ReboxingDb;User ID=sa; Password=admin1@3;TrustServerCertificate=True";
            _connection = new SqlConnection(ConString);
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter dataadapter = new SqlDataAdapter();
        }

        private void RegisterBtn_Click(object sender, EventArgs e)
        {
            _connection.Open();
            String LOGIN = "select * from Usertbl where UserName = '"+UserName.Text+"' and password = '"+PasswordlogIn.Text+"'";
            SqlCommand cmd = new SqlCommand(LOGIN, _connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            

            if (rdr.Read() == true)
            {
                new dashboard().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password, Please try again ", "Login Faild", MessageBoxButtons.OK, MessageBoxIcon.Error);
                UserName.Text = "";
                PasswordlogIn.Text = "";
                UserName.Focus();

            }
           



        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            UserName.Text = "";
            PasswordlogIn.Text = "";
            UserName.Focus();
        }

        private void ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowPassword.Checked)
            {
                PasswordlogIn.PasswordChar = '\0';
               

            }
            else
            {
                PasswordlogIn.PasswordChar = '*';
               
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {
            new FrmRegister().Show();
            this.Hide();
        }

        private void PasswordlogIn_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
